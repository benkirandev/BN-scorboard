Config = {}


------------------------------MAIN ---------
Config.Framework = "newqb" -- newqb, oldqb, esx
Config.BotToken = "" -- Insert bot token if Config.Service set to "discord" -- https://www.youtube.com/watch?v=-m-Z7Wav-fM
Config.SteamApiKey = "" -- Insert steam api key if Config.Service set to "steam" -- https://steamcommunity.com/dev/apikey 

Config.OpenKey = 'e'
Config.MaxPlayer = '127'
Config.Service = 'discord' -- steam , discord , none
Config.ServerName = 'Codem RolePlay'